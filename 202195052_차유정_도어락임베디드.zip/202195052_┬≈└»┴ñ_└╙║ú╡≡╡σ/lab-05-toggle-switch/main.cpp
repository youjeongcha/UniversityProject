#include "mbed.h"

#define GREEN_LED_PIN PA_13
#define FIRST_BIN_PIN PA_14

DigitalOut greenLed(GREEN_LED_PIN);
DigitalIn firstBtn(FIRST_BIN_PIN);

void setup() {
	greenLed = 0;
}

int main() {
	
	setup();
	
    while(1) {
      if (firstBtn == 0) {
//				greenLed = greenLed == 1 ? 0 : 1;  // greenled = 1 -> 0 
				wait(0.1);	//debouncing delay
				greenLed = !greenLed;
				
				wait(1.5);
			}			
    }
}
